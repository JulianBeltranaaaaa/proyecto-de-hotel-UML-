public class Usuario {
    private String nombre;
    private int id;
    private int telefono;
    private String correo;
    private String contraseña;
    private Boolean estado;

    // Constructor
    public Usuario(Boolean estado) {
        this.estado = estado;
    }

    // Getter
    public String getNombre() {
        return this.nombre;
    }

    public int getId() {
        return this.id;
    }

    public int getTelefono() {
        return this.telefono;
    }

    public String getCorreo() {
        return this.correo;
    }

    public String getContraseña() {
        return this.contraseña;
    }

    public Boolean getEstado() {
        return this.estado;
    }

    // Setter
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public void setEstado(Boolean estado) {
        this.estado = estado;
    }

    // Functions

    public void registrarse() {
        System.out.println("Usuario registrandose...");
    }

    public void iniciar() {
        System.out.println("Usuario iniciando...");
    }

    public void buscarHabitaciones() {
        System.out.println("Usuario buscando habitaciones...");
    }

    public void reservarHabitacion() {
        System.out.println("Usuario reservando habitacion...");
    }

    public void cancelarReserva() {
        System.out.println("Usuario cancelando reserva...");
    }

    public void verReserva() {
        System.out.println("Usuario viendo reservas...");
    }
}