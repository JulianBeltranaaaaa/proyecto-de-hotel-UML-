import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Reserva {

    ArrayList<Habitacion> dataRooms = new ArrayList<>();

    // Constructor
    public Reserva() {

    }

    // Functions

    public static int generarNumeroAleatorio(int min, int max) {
        Random rand = new Random();
        int numeroAleatorio = rand.nextInt((max - min) + 1) + min;
        return numeroAleatorio;
    }

    public void itinerario(Usuario cliente, Scanner sc) {
        System.out.println("Bienvenido al hotel Corona tu primera vez.\n");

        System.out.println("Itinerario del hotel:");
        System.out.println("1.Añadir Habitacion");
        System.out.println("2.Eliminar Habitacion");
        System.out.println("3.Cambiar detalles de habitacion");
        System.out.println("4.Ver lista de habitaciones");
        System.out.println("5.Ver lista de reservas");
        System.out.println("6.Reservar habitacion\n");

        System.out.print("Seleccione una opcion: ");

        int option = sc.nextInt();
        if (option == 1) {
            añadirHabitacion(cliente, sc);
        } else if (option == 2) {
            eliminarHabitacion(cliente, sc);
        } else if (option == 3) {
            cambiarDetallesHabitacion(cliente, sc);
        } else if (option == 4) {
            verListaHabitaciones(cliente, sc);
        } else if (option == 5) {
            verListaReservas(cliente, sc);
        } else if (option == 6) {
            reservarHabitacion(cliente, sc);
        }
    }

    public void añadirHabitacion(Usuario cliente, Scanner sc) {
        System.out.println("Tipos de habitacion:");
        System.out.println("1.Habitacion individual");
        System.out.println("2.Habitacion doble");
        System.out.println("3.Habitacion Suite");

        System.out.print("Elija una opcion: ");
        int option = sc.nextInt();
        String tipo;
        int capacidad;
        Double precio;
        if (option == 1) {
            tipo = "unico";
            capacidad = 1;
            precio = 5000.0;
        } else if (option == 2) {
            tipo = "doble";
            capacidad = 2;
            precio = 7500.0;
        } else {
            tipo = "suite";
            capacidad = 4;
            precio = 9999.0;
        }

        Habitacion nuevaHabitacion = new Habitacion(generarNumeroAleatorio(1000, 9999), precio, tipo, capacidad, false);
        dataRooms.add(nuevaHabitacion);

        System.out.println("Se añadio la habitacion correctamente, consulte la lista de habitaciones.\n");
        itinerario(cliente, sc);
    }

    public void eliminarHabitacion(Usuario cliente, Scanner sc) {
        System.out.print("Digite el id de la habitacion que desea eliminar: ");
        int id = sc.nextInt();
        Boolean isFind = false;
        for (Habitacion item : dataRooms) {
            if (id == item.getId()) {
                isFind = true;
                dataRooms.remove(item);
                break;
            }
        }

        if (isFind) {
            System.out.println("La habitacion con el id " + id + " ha sido eliminada.\n");
        } else {
            System.out.println("No se pudo encontrar la habitacion con el id " + id + "\n");
        }

        itinerario(cliente, sc);
    }

    public void cambiarDetallesHabitacion(Usuario cliente, Scanner sc) {
        System.out.print("Digite el id de la habitacion que sea cambiarle los detalles: ");
        int id = sc.nextInt();
        Boolean isFind = false;
        Habitacion itemFind = null;
        for (Habitacion item : dataRooms) {
            if (item.getId() == id) {
                isFind = true;
                itemFind = item;
                break;
            }
        }

        if (isFind) {
            System.out.print("Digite el numero precio de la habitacion: ");
            Double precio = sc.nextDouble();

            System.out.print("Digite la nueva capacidad de la habitacion: ");
            int capacidad = sc.nextInt();

            itemFind.setPrecio(precio);
            itemFind.setCapacidad(capacidad);

            System.out.println("Datos cambiados correctamente. \n");
            itinerario(cliente, sc);
        }
    }

    public void verListaHabitaciones(Usuario cliente, Scanner sc) {
        if (dataRooms.size() == 0) {
            System.out.println("No se encontraron habitaciones, por favor crea una.");
            itinerario(cliente, sc);
            return;
        }

        System.out.println("Lista de habitaciones:");
        System.out.println(
                "| " + "ID  " + " | " + "C" + " | " + "Tipo " + " | " + "Precio" + " | " + "Est " + " |");
        for (Habitacion item : dataRooms) {
            System.out.print("| " + item.getId() + " | ");
            System.out.print(item.getCapacidad() + " | ");
            System.out.print(item.getTipo() + " | ");
            System.out.print(item.getPrecio() + " | ");
            System.out.print(item.getEstado() + " |");
            System.out.println("");
        }

        System.out.println("\n");
        itinerario(cliente, sc);
    }

    public void verListaReservas(Usuario cliente, Scanner sc) {
        if (dataRooms.size() == 0) {
            System.out.println("No se encontraron habitaciones, por favor crea una.");
            itinerario(cliente, sc);
            return;
        }

        Boolean isFind = false;

        System.out.println("Lista de habitaciones reservadas:");
        System.out.println(
                "| " + "ID  " + " | " + "C" + " | " + "Tipo " + " | " + "Precio" + " | " + "Est " + " |");
        for (Habitacion item : dataRooms) {
            if (item.getEstado() == true) {
                isFind = true;
                System.out.print("| " + item.getId() + " | ");
                System.out.print(item.getCapacidad() + " | ");
                System.out.print(item.getTipo() + " | ");
                System.out.print(item.getPrecio() + " | ");
                System.out.print(item.getEstado() + " |");
                System.out.println("");
            }
        }

        if (isFind == false) {
            System.out.println("No se encontraron habitaciones reservadas.\n");
            itinerario(cliente, sc);
            return;
        }

        System.out.println("\n");
        itinerario(cliente, sc);
    }

    public void reservarHabitacion(Usuario cliente, Scanner sc) {
        if (dataRooms.size() == 0) {
            System.out.println("No hay habitaciones en el hotel, por favor crea una.\n");
            itinerario(cliente, sc);
            return;
        }

        Boolean isFind = false;
        for (Habitacion item : dataRooms) {
            if (item.getEstado() == false) {
                isFind = true;
                break;
            }
        }

        System.out.println("Lista de habitaciones disponibles");
        System.out.println(
                "| " + "ID  " + " | " + "C" + " | " + "Tipo " + " | " + "Precio" + " | " + "Est " + " |");
        for (Habitacion item : dataRooms) {
            if (item.getEstado() == false) {
                isFind = true;
                System.out.print("| " + item.getId() + " | ");
                System.out.print(item.getCapacidad() + " | ");
                System.out.print(item.getTipo() + " | ");
                System.out.print(item.getPrecio() + " | ");
                System.out.print(item.getEstado() + " |");
                System.out.println("");
            }
        }

        if (isFind == false) {
            System.out.println("No se encontraron habitaciones disponibles.");
            itinerario(cliente, sc);
            return;
        }

        System.out.print("Digite el id de la habitacion que desea reservar: ");
        int id = sc.nextInt();

        Boolean isFindId = false;
        for (Habitacion item : dataRooms) {
            if (item.getId() == id) {
                isFindId = true;
                item.setEstado(true);
                break;
            }
        }

        if (isFindId == false) {
            System.out.println("La habitacion el id " + id + " no existe.\n");
            reservarHabitacion(cliente, sc);
        } else {
            System.out.println("Habitacion con el id " + id + " reservada con exito.\n");
            itinerario(cliente, sc);
        }
    }
}