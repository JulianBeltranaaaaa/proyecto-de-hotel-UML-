public class Habitacion {
    private int id;
    private Double precio;
    private String tipo;
    private int capacidad;
    private Boolean estado;

    // Constructor
    public Habitacion(int id, Double precio, String tipo, int capacidad, Boolean estado) {
        this.id = id;
        this.precio = precio;
        this.tipo = tipo;
        this.capacidad = capacidad;
        this.estado = estado;
    }

    // Getter
    public int getId() {
        return this.id;
    }

    public double getPrecio() {
        return this.precio;
    }

    public String getTipo() {
        return this.tipo;
    }

    public int getCapacidad() {
        return this.capacidad;
    }

    public Boolean getEstado() {
        return this.estado;
    }

    // Setter
    public void setId(int id) {
        this.id = id;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public void setEstado(Boolean estado) {
        this.estado = estado;
    }
}
