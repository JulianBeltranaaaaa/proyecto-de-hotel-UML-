import java.io.Console;
import java.util.Scanner;

public class Hotel {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Console console = System.console();

        Usuario cliente = new Usuario(false);
        Login login = new Login();

        if (console == null) {
            System.out.println("La consola no esta disponible.");
            System.exit(1);
        }

        if (!cliente.getEstado()) {
            login.Registrarse(cliente, sc, console);
        } else {
            login.InicioSesion(cliente, sc, console);
        }

        Reserva reserva = new Reserva();
        reserva.itinerario(cliente, sc);
    }
}