import java.io.Console;
import java.util.Scanner;

public class Login {
    private String nombre;
    private String correo;
    private int contraseña;

    // Constructor
    public Login() {

    }

    // Getter
    public String getNombre() {
        return this.nombre;
    }

    public String getCorreo() {
        return this.correo;
    }

    public int getContraseña() {
        return this.contraseña;
    }

    // Setter
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setContraseña(int contraseña) {
        this.contraseña = contraseña;
    }

    // Functions

    public void InicioSesion(Usuario cliente, Scanner sc, Console console) {
        System.out.println("¡Bienvenido al Hotel Corona tu primera vez!");

        System.out.print("Ingrese su correo: ");
        String correo = sc.next();

        if (!cliente.getCorreo().equals(correo)) {
            System.out.println("Correo invalido.");
            InicioSesion(cliente, sc, console);
            return;
        }

        char[] passwordArray = console.readPassword("Ingrese su contraseña: ");

        String passwordString = new String(passwordArray);

        if (!cliente.getContraseña().equals(passwordString)) {
            System.out.println("Contraseña invalida.");
            InicioSesion(cliente, sc, console);
            return;
        }

        System.out.println("!Inicio de sesion con exito¡\n");
    }

    public void Registrarse(Usuario cliente, Scanner sc, Console console) {
        System.out.println("¡Bienvenido al Hotel Corona tu primera vez!");

        System.out.println("Registrate");

        System.out.print("Ingrese su nombre: ");
        String nombre = sc.next();

        System.out.print("Ingrese su numero de identificacion: ");
        int id = sc.nextInt();

        System.out.print("Ingrese su numero de telefono: ");
        int telefono = sc.nextInt();

        System.out.print("Ingrese su correo electronico: ");
        String correo = sc.next();

        char[] passwordArray = console.readPassword("Ingrese su contraseña: ");
        String passwordString = new String(passwordArray);

        cliente.setNombre(nombre);
        cliente.setId(id);
        cliente.setTelefono(telefono);
        cliente.setCorreo(correo);
        cliente.setContraseña(passwordString);

        System.out.println("!Registro completado con exito¡\n");
        InicioSesion(cliente, sc, console);
    }

}